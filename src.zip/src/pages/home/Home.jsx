import './Home.css';
import SideNavbar from '../../components/sideNavbar/SideNavbar';
import TopNavBar from '../../components/topNavbar/TopNavbar';
import ContentArea from '../../components/contentArea/ContentArea';
import RightSideContent from '../../components/rightSideContent/RightSideContent';
import homeIcon from '../../icons/homeIcon.svg';
import hashIcon from '../../icons/hashIcon.svg';
import blackBell from '../../icons/blackBell.svg';
import mailIcon from '../../icons/mailIcon.svg';
import homeIconActive from '../../icons/homeIconActive.svg';
import hashIconActive from '../../icons/hashIconActive.svg';
import blackBellActive from '../../icons/blackBellActive.svg';
import mailIconActive from '../../icons/mailIconActive.svg';
import { useRef, useState } from 'react';
import { iconClick } from '../../utils/Home';
import tweetIcon from '../../icons/tweetIcon.svg';

export default function Home()
{
    const bottomHomeIcon=useRef();
    const bottomExploreIcon=useRef();
    const bottomBellIcon=useRef();
    const bottomMailIcon=useRef();
    const [activeIcon,setActiveIcon]=useState(bottomHomeIcon);
    const [oldImg,setOldImg]=useState(homeIcon)

    return(
        <div className='pageOuter'>
            <div className='home'>
                <div className='sideNavbarTag'>
                    <SideNavbar/>
                </div>
                <div className='middleAndRightPage'>
                    <div className='middlepage'>
                        <div className='topNavbarTag'>
                            <TopNavBar/>
                        </div>
                        <div className='contentAreaTag'>
                            <ContentArea/>
                        </div>
                    </div>
                    <div className='rightSideContentTag'>
                        <RightSideContent/>
                    </div>
                </div>
            </div>
            <div className='floatingTweetButtonOuter'>
                <div className='floatingTweetButton'>
                    <div className='floatingTweetButtonText'>
                        <img src={tweetIcon}/>
                        <p>Tweet</p>
                    </div>
                </div>
            </div>
            <div className='bottomNavbarOuter'>
                <div className='bottomNavbar'>
                    <div className='bottomHomeIcon bottomIconDiv' onClick={()=>iconClick(bottomHomeIcon,homeIconActive,activeIcon,setActiveIcon,oldImg,setOldImg)}>
                        <img ref={bottomHomeIcon} src={homeIconActive}/>
                    </div>
                    <div className='bottomExploreIcon bottomIconDiv' onClick={()=>iconClick(bottomExploreIcon,hashIconActive,activeIcon,setActiveIcon,oldImg,setOldImg)}>
                        <img ref={bottomExploreIcon} src={hashIcon}/>
                    </div>
                    <div className='bottomBellIcon bottomIconDiv' onClick={()=>iconClick(bottomBellIcon,blackBellActive,activeIcon,setActiveIcon,oldImg,setOldImg)}>
                        <img ref={bottomBellIcon} src={blackBell}/>
                    </div>
                    <div className='bottomMailIcon bottomIconDiv' onClick={()=>iconClick(bottomMailIcon,mailIconActive,activeIcon,setActiveIcon,oldImg,setOldImg)}>
                        <img ref={bottomMailIcon} src={mailIcon}/>
                    </div>
                </div>
            </div>
        </div>
    )
}