export default function Signup_step(props)
{
    return(
        <div className="su1_2-s1">
            <p>Step {props.step} of 5</p>
        </div>
    )
}