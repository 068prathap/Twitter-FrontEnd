import './SideNavbarTab.css';
import { activeTab } from '../../utils/SideNavbarTab';
import { useEffect, useState } from 'react';

export default function SideNavbarTab(props)
{

    useEffect(()=>{
        props.pText=='Home'?activeTab(props.active,props.setActive,props.pRef,props.activeImg,props.oldImg,props.imgRef,props.imgActive,props.setActiveImg,props.setOldImg,props.img):<></>;
    },[])

    return(
        <div className={props.class} onClick={()=>props.pText!='More'?activeTab(props.active,props.setActive,props.pRef,props.activeImg,props.oldImg,props.imgRef,props.imgActive,props.setActiveImg,props.setOldImg,props.img):<></>}>
            <img ref={props.imgRef} className={props.imgClass} src={props.img}/>
            <p ref={props.pRef} className={props.pClass}>{props.pText}</p>
        </div>
    )
}