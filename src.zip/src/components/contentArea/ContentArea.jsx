import './ContentArea.css'

export default function ContentArea()
{
    return(
        <div className='contentArea'>
            <p>content area</p>
        </div>
    )
}