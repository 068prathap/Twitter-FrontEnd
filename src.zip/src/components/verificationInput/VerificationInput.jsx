import './VerificationInput.css';
import {OnFocus} from '../../utils/VerificationInput'
import { useRef } from 'react'; 
import {OnBlur} from '../../utils/VerificationInput'
import {OnChange} from '../../utils/VerificationInput'


export default function VerifcationInput(props)
{
    const code=useRef();
    const codeLabel=useRef();

    return(
        <div ref={code} className={props.class}>
            <p ref={codeLabel} className={props.labelClass}>Verification code</p>
            <input ref={props.inputRef} type={props.inputType} onFocus={()=>OnFocus(code,codeLabel)} onBlur={()=>OnBlur(code,codeLabel,props.inputRef)} onChange={()=>OnChange(props.inputRef,props.setButtonChange,props.setButtonActive)}></input>
        </div>
    )
}