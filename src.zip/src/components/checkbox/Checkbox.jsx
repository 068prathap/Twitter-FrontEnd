import checkBox from '../../icons/checkBox.svg';
import './Checkbox.css'

export default function Checkbox()
{
    return(
        <img className='checkboxImg' src={checkBox} alt="ss" srcset="" />
    )
}