import './TopNavbar.css';

export default function TopNavBar()
{
    return(
        <div className='topNavbar'>
            <p>top navbar</p>
        </div>
    )
}