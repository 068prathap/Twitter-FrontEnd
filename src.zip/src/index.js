import React, {useEffect, useState } from 'react';
import ReactDOM from 'react-dom/client';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import './Index.css';
import LandingPage from './pages/landingPage/LandingPage';
import ForgotPassword from './pages/forgotPassword/ForgotPassword'
import Home from './pages/home/Home';

var root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
    <Routes>
      <Route path='/' element={<LandingPage/>}/>
      <Route path='signup' element={<LandingPage signup={true}/>}/>
      <Route path='login' element={<LandingPage login={true}/>}/>
      <Route path='password_reset' element={<ForgotPassword/>}/>
      <Route path='home' element={<Home/>}/>
    </Routes>
  </BrowserRouter>
)