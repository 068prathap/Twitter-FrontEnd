export function ChangingInfo(liveLink,step1Link)
{
    liveLink.current.style.display='none';
    step1Link.current.style.display='block';
}