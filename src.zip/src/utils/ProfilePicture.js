import { ApiCall } from "./ApiCall";

export function profileChange(addProfileInput,setProfile,profileSetupIcons,removeProfile,setButtonClass,setButtonText)
{
    console.log('hi');
    setProfile(URL.createObjectURL(addProfileInput.current.files[0]));
    profileSetupIcons.current.classList.add('profileSetupIcons-1');
    removeProfile.current.style.display='flex';
    setButtonClass('Next-1');
    setButtonText('Next');
}

export function removeImage(defaultProfile,setProfile,profileSetupIcons,removeProfile,setButtonClass,setButtonText,addProfileInput)
{
    setProfile(defaultProfile);
    profileSetupIcons.current.classList.remove('profileSetupIcons-1');
    removeProfile.current.style.display='none';
    addProfileInput.current.value='';
    setButtonClass('skipProfile');
    setButtonText('Skip for now');
}
export function navigationForward(nextLink,liveLink,profile)
{
    liveLink.current.style.display='none';
    nextLink.current.style.display='block';
    let profileImage={
        'path':profile
    }
    ApiCall('postHeader',profileImage,'uploadprofilepic');  
}