import { ApiCall } from "./ApiCall"

export async function navigationForward(password,userAccount,userType,wrongPassword,navigate)
{
    let data={
        'password':password,
        [userType]:userAccount
    }
    let response=await ApiCall('post',data,'login');
    if(response=='Wrong Password!')
    {
        wrongPassword.current.style.display='block';
        setTimeout(() => {
            wrongPassword.current.style.display='none';
        }, 3000);
    }
    else
    {
        navigate('/home');
    }
}