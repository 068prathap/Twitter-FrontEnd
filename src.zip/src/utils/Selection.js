export function Setvalue(setValue,selection)
{
    setValue(selection.current.value);
}