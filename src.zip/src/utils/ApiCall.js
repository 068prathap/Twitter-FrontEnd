import Axios from "axios";

export const ApiCall = async(method,data,link) => {
    console.log(data);
    let response;
    switch(method)
    {
        case "post":
        {
            response=await Axios.post(`${process.env.REACT_APP_IPADDRESS}${link}`,data);
            console.log(response);
            break;
        }
        case "get":
        {
            response=await Axios.get(`${process.env.REACT_APP_IPADDRESS}${link}`,data);
            break;
        }
        case 'postHeader':
        {
            response=await Axios.post(`${process.env.REACT_APP_IPADDRESS}${link}`,data,{headers :{ "authorization": `Bearer ${sessionStorage.getItem("token")}`}});
            console.log(response);
            break;
        }
    }
    return response.data;
}