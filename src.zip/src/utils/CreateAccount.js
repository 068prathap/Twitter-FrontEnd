export function navigationForward(signupStep1,createAccount)
{
    signupStep1.current.style.display='block';
    createAccount.current.style.display='none';
}