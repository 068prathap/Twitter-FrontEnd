export function iconClick(newRef,newImg,activeIcon,setActiveIcon,oldImg,setOldImg)
{
    activeIcon.current.src=oldImg;
    setOldImg(newRef.current.src);
    newRef.current.src=newImg;
    setActiveIcon(newRef);
}